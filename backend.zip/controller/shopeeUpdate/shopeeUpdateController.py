import hmac
import hashlib
import time
import os
import requests
import json
import re
from datetime import datetime, timedelta
import pytz
import math
from controller.auth.authShopee import TokenShopee
from sqlalchemy import or_
from model.shopeeModel import db, HistoricoPreco, Produtos, Anuncios, Configuracoes


class ShopeeService:
    def __init__(self):
        self.tokens = TokenShopee()
        self.host_base = "https://partner.shopeemobile.com"
        self.tz_brasil = pytz.timezone("America/Sao_Paulo")

        # Controle de progresso para concorrência
        self.cancel_requested = False
        self.sync_status = {
            "is_running": False,
            "sucessos": 0,
            "erros": 0,
            "total": 0,
            "atual": 0,
            "mensagem": "Inativo",
        }

    def _get_brasilia_time(self):
        """Retorna o horário atual no fuso de Brasília como naive datetime (sem fuso)."""
        return datetime.now(self.tz_brasil).replace(tzinfo=None)

    def _get_wait_time_config(self):
        """Busca o tempo de espera configurado no banco de dados."""
        try:
            config = Configuracoes.query.first()
            return config.dias_espera_simples if config else 15
        except:
            return 15

    def validate_price_lock(self, item_id, model_id=0):
        """
        Valida se o item/modelo está sob a trava de 15 dias da Shopee (Alteração de Preço Base).
        Retorna (is_locked, dias_faltantes, mensagem).
        """
        try:
            mid = str(model_id or "0")
            prod = Produtos.query.filter_by(
                shopee_item_id=str(item_id), shopee_model_id=mid
            ).first()

            if not prod:
                return False, 0, ""

            # Se já estiver em promoção, a Shopee geralmente permite alterar o preço promocional
            # A trava é focada em Preço Base -> Promoção ou Preço Base -> Preço Base
            if prod.preco_promocional and prod.preco_promocional > 0:
                return False, 0, ""

            if prod.preco_modificado_em:
                dias_espera = self._get_wait_time_config()
                if dias_espera <= 0:
                    return False, 0, ""

                agora = self._get_brasilia_time()
                dias_passados = (agora - prod.preco_modificado_em).days

                if dias_passados < dias_espera:
                    faltam = dias_espera - dias_passados
                    nome = prod.nome_variacao or (
                        prod.anuncio.nome if prod.anuncio else "Item"
                    )
                    msg = f"O Anúncio '{nome}' teve o preço base alterado recentemente. Aguarde {faltam} dia(s) para nova alteração ou promoção."
                    return True, faltam, msg

            return False, 0, ""
        except Exception as e:
            print(f"Erro ao validar trava de preço: {e}")
            return False, 0, ""

    def _shopee_request(self, path, creds, params=None, method="GET", json_data=None):
        """Helper centralizado para chamadas à API da Shopee."""
        timestamp = int(time.time())
        string_base = f"{creds['partner_id']}{path}{timestamp}{creds['access_token']}{creds['shop_id']}"
        sign = hmac.new(
            creds["partner_key"].encode(), string_base.encode(), hashlib.sha256
        ).hexdigest()

        default_params = {
            "partner_id": int(creds["partner_id"]),
            "shop_id": int(creds["shop_id"]),
            "timestamp": timestamp,
            "access_token": creds["access_token"],
            "sign": sign,
        }
        if params:
            default_params.update(params)

        url = f"{self.host_base}{path}"
        try:
            if method.upper() == "POST":
                resp = requests.post(
                    url, params=default_params, json=json_data, timeout=60
                )
            else:
                resp = requests.get(url, params=default_params, timeout=60)

            return resp.json(), resp.status_code
        except Exception as e:
            return {"error": str(e)}, 500

    def sincronizar_todos_anuncios(self, flask_app):
        """Dispara a sincronização global em uma Thread separada (Assíncrona)."""
        if self.sync_status["is_running"]:
            return {
                "status": "erro",
                "mensagem": "Uma sincronização já está em andamento.",
            }

        self.cancel_requested = False

        # Iniciar Thread injetando a APP
        import threading

        thread = threading.Thread(target=self._run_sync_worker, args=(flask_app,))
        thread.daemon = True
        thread.start()

        return {
            "status": "sucesso",
            "mensagem": "Sincronização iniciada em segundo plano.",
        }

    def _run_sync_worker(self, app):
        """Thread que executa a sincronização pesada utilizando processamento em lote."""
        import traceback

        ctx = app.app_context()
        ctx.push()

        try:
            self.sync_status.update(
                {
                    "is_running": True,
                    "sucessos": 0,
                    "erros": 0,
                    "total": 0,
                    "atual": 0,
                    "mensagem": "Buscando IDs na Shopee...",
                }
            )

            # 1. Validar Token
            creds, erro = self.tokens.ensure_valid_token(1)
            if erro:
                self.sync_status.update(
                    {"is_running": False, "mensagem": f"Erro de token: {erro}"}
                )
                return

            # 2. Buscar IDs
            item_ids = self.get_item_ids(creds)
            if not item_ids:
                self.sync_status.update(
                    {"is_running": False, "mensagem": "Nenhum item encontrado."}
                )
                return

            self.sync_status["total"] = len(item_ids)
            self.sync_status["mensagem"] = "Sincronizando itens em lote..."

            # 3. Processar em Lotes de 50
            BATCH_SIZE = 50
            for i in range(0, len(item_ids), BATCH_SIZE):
                if self.cancel_requested:
                    self.sync_status.update(
                        {
                            "is_running": False,
                            "mensagem": "Sincronização cancelada pelo usuário.",
                        }
                    )
                    return

                batch_ids = item_ids[i : i + BATCH_SIZE]
                self.sync_status["atual"] = min(i + len(batch_ids), len(item_ids))

                try:
                    # Sincronizar o lote
                    res_batch = self.sync_batch_from_shopee(batch_ids, creds)
                    self.sync_status["sucessos"] += res_batch.get("sucessos", 0)
                    self.sync_status["erros"] += res_batch.get("erros", 0)
                except Exception as e_batch:
                    print(f"❌ Erro fatal no lote {i//BATCH_SIZE + 1}: {str(e_batch)}")
                    self.sync_status["erros"] += len(batch_ids)

                # Pequena pausa para evitar overstrain nos buffers locais, mas muito mais rápido que o loop individual
                time.sleep(0.5)

            self.sync_status.update(
                {
                    "is_running": False,
                    "mensagem": f"Finalizado: {self.sync_status['sucessos']} sucessos, {self.sync_status['erros']} erros.",
                }
            )

            # --- NOVO: Verificar desbloqueios de 15 dias após sincronizar ---
            self.verificar_desbloqueios(item_ids)

            self.sync_status.update({"is_running": False, "mensagem": error_msg})
            # Emitir falha
            from app import socketio

            socketio.emit("sync_finished", {"sucesso": False, "erro": str(e)})
        finally:
            # Emitir sucesso se não caiu no except crítico
            if not self.sync_status.get("error_critical"):
                from app import socketio

                socketio.emit(
                    "sync_finished",
                    {
                        "sucesso": True,
                        "total": self.sync_status["total"],
                        "sucessos": self.sync_status["sucessos"],
                        "erros": self.sync_status["erros"],
                    },
                )
            ctx.pop()

    def sync_batch_from_shopee(self, item_id_list, creds):
        """Sincroniza um lote de itens da Shopee de forma eficiente."""
        from model.shopeeModel import Anuncios, Produtos

        stats = {"sucessos": 0, "erros": 0}
        agora = self._get_brasilia_time()

        try:
            # 1. Buscar Info Base em Lote
            items_info = self._get_item_base_info_batch(item_id_list, creds)
            if not items_info:
                return {"sucessos": 0, "erros": len(item_id_list)}

            # 2. Buscar Promoções em Lote
            promos_all = self._get_active_promotion_batch(item_id_list, creds)

            # Mapear promos por item_id para busca rápida
            promo_map = {str(p["item_id"]): p.get("promotion", []) for p in promos_all}

            for info in items_info:
                iid = str(info["item_id"])
                try:
                    # Garantir Anúncio (Pai)
                    anuncio = Anuncios.query.filter_by(shopee_item_id=iid).first()
                    if not anuncio:
                        anuncio = Anuncios(
                            shopee_item_id=iid,
                            nome=info.get("item_name"),
                            sku_pai=info.get("item_sku"),
                        )
                        db.session.add(anuncio)
                        db.session.flush()
                    else:
                        anuncio.nome = info.get("item_name", anuncio.nome)
                        anuncio.sku_pai = info.get("item_sku", anuncio.sku_pai)

                    promos_list = promo_map.get(iid, [])
                    has_model = info.get("has_model", False)

                    if has_model:
                        # 1. Limpeza Proativa de Fantasmas: Se tem variações, o model_id "0" deve ser removido
                        Produtos.query.filter_by(
                            shopee_item_id=iid, shopee_model_id="0"
                        ).delete()

                        modelos = self._get_models(iid, creds)
                        for m in modelos:
                            mid = str(m.get("model_id"))
                            mid_int = int(m.get("model_id", 0))

                            # Prioriza "Discount Promotions" e ignora "Whole Sale"
                            matches = [
                                p
                                for p in promos_list
                                if str(p.get("model_id", 0)) == str(mid_int)
                                and p.get("promotion_type") != "Whole Sale"
                            ]
                            promo_v = next(
                                (
                                    p
                                    for p in matches
                                    if p.get("promotion_type") == "Discount Promotions"
                                ),
                                matches[0] if matches else None,
                            )
                            p_info = m.get("price_info", [{}])[0]
                            p_original = p_info.get("original_price", 0.0)
                            p_atual = p_info.get("current_price", 0.0)

                            prod = Produtos.query.filter_by(
                                shopee_item_id=iid, shopee_model_id=mid
                            ).first()
                            if not prod:
                                prod = Produtos(
                                    anuncio_id=anuncio.id,
                                    shopee_item_id=iid,
                                    shopee_model_id=mid,
                                )
                                db.session.add(prod)

                            prod.nome_variacao = m.get("model_name")
                            prod.sku = m.get("model_sku")
                            prod.ean = m.get("gtin_code") or m.get(
                                "ean"
                            )  # Captura o EAN/GTIN da variação
                            prod.situacao = info.get(
                                "item_status"
                            )  # Status do anúncio pai reflete nas variações
                            prod.preco_base = p_original

                            if promo_v:
                                v_promo = promo_v.get("promotion_price_info", [{}])[
                                    0
                                ].get("promotion_price")
                                prod.preco_promocional = (
                                    v_promo
                                    if v_promo
                                    else (p_atual if p_atual != p_original else None)
                                )
                                prod.promotion_id = str(
                                    promo_v.get("promotion_id")
                                    or promo_v.get("discount_id")
                                )
                            elif p_atual != p_original and p_atual > 0:
                                prod.preco_promocional = p_atual
                                prod.promotion_id = "PROMO_DETECTADA"
                            else:
                                prod.preco_promocional = None
                                prod.promotion_id = None

                            # Limpeza de IDs legados se encontrados
                            if prod.promotion_id == "1":
                                prod.promotion_id = None

                            prod.updated_at = agora
                        anuncio.updated_at = agora

                        # (Removido daqui pois agora é proativo no início do bloco has_model)
                        pass
                    else:
                        p_info = info.get("price_info", [{}])[0]
                        p_original = p_info.get("original_price", 0.0)
                        p_atual = p_info.get("current_price", 0.0)
                        # Prioriza "Discount Promotions" e ignora "Whole Sale"
                        valid_promos = [
                            p
                            for p in promos_list
                            if p.get("promotion_type") != "Whole Sale"
                        ]
                        promo_v = next(
                            (
                                p
                                for p in valid_promos
                                if p.get("promotion_type") == "Discount Promotions"
                            ),
                            valid_promos[0] if valid_promos else None,
                        )

                        prod = Produtos.query.filter_by(
                            shopee_item_id=iid, shopee_model_id="0"
                        ).first()
                        if not prod:
                            prod = Produtos(
                                anuncio_id=anuncio.id,
                                shopee_item_id=iid,
                                shopee_model_id="0",
                            )
                            db.session.add(prod)

                        prod.sku = anuncio.sku_pai
                        prod.ean = info.get("gtin_code") or info.get(
                            "ean"
                        )  # Captura o EAN/GTIN do anúncio simples
                        prod.situacao = info.get("item_status")
                        prod.preco_base = p_original
                        if promo_v:
                            v_promo = (
                                promo_v.get("promotion_price_info", [{}])[0].get(
                                    "promotion_price"
                                )
                                if promo_v.get("promotion_price_info")
                                else p_atual
                            )
                            prod.preco_promocional = v_promo
                            prod.promotion_id = str(
                                promo_v.get("promotion_id")
                                or promo_v.get("discount_id")
                            )
                        else:
                            prod.preco_promocional = None
                            prod.promotion_id = None

                        # Limpeza de IDs legados
                        if prod.promotion_id == "1":
                            prod.promotion_id = None

                        prod.updated_at = agora
                        anuncio.updated_at = agora

                    stats["sucessos"] += 1
                except Exception as e_item:
                    print(f"⚠️ Erro ao processar item {iid} no batch: {e_item}")
                    stats["erros"] += 1
                    # Registrar erro de processamento individual no histórico
                    self._log_and_save_update(
                        item_id=iid,
                        model_id="0",
                        nome=info.get("item_name", "Desconhecido"),
                        p_antigo=0.0,
                        p_novo=0.0,
                        status="erro",
                        msg=f"Erro no batch sync: {str(e_item)}",
                        sku=info.get("item_sku", ""),
                    )

            db.session.commit()

            # Verificar desbloqueios após o commit para garantir que os dados estão atualizados
            try:
                self.verificar_desbloqueios(item_id_list)
            except:
                pass

            return stats
        except Exception as e_batch:
            db.session.rollback()
            print(f"❌ Erro crítico no sync_batch_from_shopee: {e_batch}")
            return {"sucessos": 0, "erros": len(item_id_list)}

    def get_sync_progress(self):
        """Retorna o estado atual da sincronização."""
        return self.sync_status

    def get_item_ids(self, creds):
        """Busca todos os IDs de itens da loja (NORMAL e UNLIST)."""
        path = "/api/v2/product/get_item_list"
        item_ids = []

        # Filtros de status para sincronização total
        statuses = ["NORMAL", "UNLIST"]

        for status in statuses:
            offset = 0
            has_next_page = True

            while has_next_page:
                if self.cancel_requested:
                    return item_ids

                params = {
                    "offset": offset,
                    "page_size": 100,
                    "item_status": status,
                }

                resp_json, code = self._shopee_request(path, creds, params=params)
                if code != 200:
                    break

                response = resp_json.get("response", {})
                items = response.get("item", [])
                for item in items:
                    item_ids.append(item["item_id"])

                has_next_page = response.get("has_next_page", False)
                if has_next_page:
                    offset += 100

        return item_ids

    def cancelar_sincronizacao(self):
        """Solicita o cancelamento da sincronização em andamento."""
        self.cancel_requested = True
        return {"status": "sucesso", "mensagem": "Cancelamento solicitado."}

    def verificar_desbloqueios(self, item_id_list):
        """Verifica se itens saíram do estado de bloqueio de 15 dias."""
        try:
            from model.shopeeModel import Produtos, Configuracoes

            config = Configuracoes.query.first()
            dias_espera = config.dias_espera_simples if config else 15
            agora = self._get_brasilia_time()

            for iid in item_id_list:
                prods = Produtos.query.filter_by(shopee_item_id=str(iid)).all()
                for p in prods:
                    if p.preco_modificado_em:
                        dias_passados = (agora - p.preco_modificado_em).days
                        # Se o bloqueio acabou nos últimos 2 dias e ainda não notificamos
                        if (
                            dias_passados >= dias_espera
                            and dias_passados <= dias_espera + 1
                            and not p.notificado_desbloqueio
                        ):
                            self._criar_notificacao(
                                tipo="desbloqueio",
                                titulo=p.anuncio.nome if p.anuncio else p.nome_variacao,
                                mensagem=f"Produto Desbloqueado e Pronto para ser Adicionado em Promoção.",
                                item_id=p.shopee_item_id,
                                model_id=p.shopee_model_id,
                            )
                            p.notificado_desbloqueio = True
                            db.session.add(p)
                        elif dias_passados < dias_espera:
                            # Opcional: Logar bloqueio se for detectado agora
                            pass
            db.session.commit()
        except Exception as e:
            print(f"?? Erro ao verificar desbloqueios: {e}")

    def verificar_todos_desbloqueios(self):
        """Varre todos os produtos com trava e gera notificações para os liberados."""
        try:
            from model.shopeeModel import Produtos
            # Busca IDs únicos que possuem trava de data
            all_items = Produtos.query.with_entities(Produtos.shopee_item_id).filter(Produtos.preco_modificado_em.isnot(None)).distinct().all()
            item_ids = [i[0] for i in all_items]
            if item_ids:
                self.verificar_desbloqueios(item_ids)
            return True
        except Exception as e:
            print(f"?? Erro na verificação global: {e}")
            return False

    def sync_item_from_shopee(self, item_id):
        """
        Sincroniza um único item.
        Refatorado para utilizar a lógica de lote para evitar código duplicado.
        """
        try:
            creds, erro = self.tokens.ensure_valid_token(1)
            if erro:
                return {"status": "erro", "mensagem": erro}

            res = self.sync_batch_from_shopee([item_id], creds)

            if res.get("sucessos", 0) > 0:
                return {"status": "sucesso"}
            return {"status": "erro", "mensagem": "Falha na sincronização do item."}
        except Exception as e:
            return {"status": "erro", "mensagem": str(e)}

    def update_price(
        self, preco_desejado, item_id=None, sku=None, model_id=None, user_id=None
    ):
        creds, erro = self.tokens.ensure_valid_token(1)
        if erro:
            return {"status": "erro", "mensagem": f"Erro de autenticação: {erro}"}, 401

        identificador = str(item_id or sku or "").strip()
        if not identificador:
            return {"status": "erro", "mensagem": "item_id or sku é obrigatório"}, 400

        # Buscar o preço atual antes de alterar para o histórico
        from model.shopeeModel import Produtos

        p_antigo = 0.0
        p_nome = "Produto"
        try:
            prod_local = Produtos.query.filter_by(
                shopee_item_id=str(identificador), shopee_model_id=str(model_id or "0")
            ).first()
            if prod_local:
                p_antigo = (
                    prod_local.preco_promocional
                    if (
                        prod_local.preco_promocional
                        and prod_local.preco_promocional > 0
                    )
                    else prod_local.preco_base
                )
                p_nome = prod_local.nome_variacao or (
                    prod_local.anuncio.nome if prod_local.anuncio else "Produto"
                )
        except:
            pass

        resultado = self._atualizar_na_shopee(
            int(identificador), int(model_id or 0), float(preco_desejado), creds
        )
        return resultado, 200

    def _log_and_save_update(
        self,
        item_id,
        model_id,
        nome,
        p_antigo,
        p_novo,
        status,
        msg,
        sku=None,
        item_info=None,
        promo_info=None,
        usuario_id=None,
        origem=None,
    ):
        """
        Consolida o registro de histórico e a atualização do banco de dados local.
        """
        try:
            from model.shopeeModel import HistoricoPreco, Produtos, db

            agora_br = self._get_brasilia_time()

            # Auto-detectar usuario_id do contexto Flask se não fornecido
            if usuario_id is None:
                try:
                    from flask import g

                    if hasattr(g, "current_user") and g.current_user:
                        usuario_id = g.current_user.id
                except Exception:
                    pass

            # 1. Gerar mensagem detalhada se for sucesso
            if status == "sucesso" and msg == "Atualizado":
                if promo_info:
                    msg = f"Promoção atualizada"
                else:
                    msg = f"Preço atualizado"

            # 2. Registrar no Histórico
            novo_log = HistoricoPreco(
                shopee_item_id=str(item_id),
                shopee_model_id=str(model_id),
                nome_produto=nome,
                preco_anterior=float(p_antigo),
                preco_atual=float(p_novo),
                status="sucesso" if status == "sucesso" else "erro",
                mensagem=msg,
                sku=sku,
                origem=origem,
                criado_em=agora_br,
                usuario_id=usuario_id,
            )
            db.session.add(novo_log)

            # 2. Se foi um sucesso, atualizar também o registro do produto no banco local
            if status == "sucesso":
                prod = Produtos.query.filter_by(
                    shopee_item_id=str(item_id), shopee_model_id=str(model_id)
                ).first()

                # Fallback: Se não achou com model_id="0", tenta o primeiro produto do item
                if not prod and str(model_id) == "0":
                    prod = Produtos.query.filter_by(shopee_item_id=str(item_id)).first()
                if prod:
                    # Se tiver info de promoção, atualizar preco_promocional e ID
                    if promo_info:
                        prod.preco_promocional = float(p_novo)
                        prod.promotion_id = str(
                            promo_info.get("promotion_id")
                            or promo_info.get("discount_id")
                        )
                    else:
                        # Se não for promoção, atualiza o preco_base e limpa promocional
                        prod.preco_base = float(p_novo)
                        prod.preco_promocional = None
                        prod.promotion_id = None
                        prod.preco_modificado_em = (
                            agora_br  # Atualiza a trava SOMENTE para preço base
                        )
                        prod.notificado_desbloqueio = False # Resetar flag de notificação de desbloqueio
                        dias_espera = self._get_wait_time_config()
                        self._criar_notificacao(
                            tipo="bloqueio",
                            titulo=nome,
                            mensagem=f"Esse anuncio está temporariamente bloqueado por Segurança, aguarde {dias_espera} dias para alterar o preço novamente ou Adicione ele em uma Promoção.",
                            item_id=str(item_id),
                            model_id=str(model_id),
                        )

                    prod.updated_at = agora_br
                    # Atualizar o pai também se existir
                    if prod.anuncio:
                        prod.anuncio.updated_at = agora_br

            db.session.commit()
        except Exception as e:
            db.session.rollback()
            # Log de fallback em caso de erro no banco
            error_msg = (
                f"[DB ERROR] Falha ao salvar evento ({item_id}:{model_id}): {str(e)}"
            )
            print(error_msg)

    def _atualizar_na_shopee(
        self,
        item_id,
        model_id,
        preco_novo,
        creds,
        custom_msg=None,
        force_promotion=False,
        origem=None,
    ):
        """
        Lógica principal de atualização na Shopee.
        Suporta: Produtos simples, variações, combos, kits.
        Detecta promoções automaticamente.
        """
        LOG_DIR = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "..", "..", "logs"
        )
        os.makedirs(LOG_DIR, exist_ok=True)
        log_path = os.path.join(LOG_DIR, "shopee_debug.json")

        try:
            # Validação de entrada
            if not item_id or preco_novo <= 0:
                return {
                    "status": "erro",
                    "mensagem": f"item_id={item_id}, preco_novo={preco_novo} - Valores inválidos",
                }

            # --- PASSO 1: Buscar info do item na Shopee ---
            item_info = self._get_item_base_info(item_id, creds)

            if not item_info:
                return {
                    "status": "erro",
                    "mensagem": f"Item {item_id} não encontrado na Shopee. Verifique o ID.",
                }

            has_model = item_info.get("has_model", False)
            item_name = item_info.get("item_name", f"Item {item_id}")

            # --- PASSO 2: Obter preço atual ---
            preco_atual = 0.0
            try:
                price_info = item_info.get("price_info") or []
                if price_info:
                    preco_atual = price_info[0].get("current_price", 0.0)
            except Exception as e:
                pass

            # Se o item tem modelos e o model_id > 0, buscar preço do modelo específico
            if has_model and model_id > 0:
                models = self._get_models(item_id, creds)
                modelo_encontrado = False
                for m in models:
                    if int(m.get("model_id", 0)) == model_id:
                        try:
                            preco_atual = m["price_info"][0]["current_price"]
                            modelo_encontrado = True
                            break
                        except (KeyError, IndexError) as e:
                            pass

                if not modelo_encontrado:
                    return {
                        "status": "erro",
                        "mensagem": f"Modelo {model_id} não encontrado no item {item_id}",
                    }
            else:
                # Mesmo que não tenha modelos (simples), se o usuário passou um model_id,
                # vamos permitir e tratar no payload conforme o status 'has_model' da Shopee.
                pass

            # --- PASSO 3: Identificar alvos e atualizar ---
            alvos = []
            if has_model:
                models = self._get_models(item_id, creds)
                if model_id > 0:
                    # Alvo é um modelo específico
                    m_alvo = next(
                        (m for m in models if int(m.get("model_id", 0)) == model_id),
                        None,
                    )
                    if m_alvo:
                        alvos.append(m_alvo)
                    else:
                        return {
                            "status": "erro",
                            "mensagem": f"Modelo {model_id} não encontrado",
                        }
                else:
                    # Alvo são TODOS os modelos (Alterar Tudo)
                    alvos = models
            else:
                # Alvo é o produto simples (sem modelos)
                alvos = [
                    {
                        "model_id": 0,
                        "model_name": item_name,
                        "price_info": item_info.get("price_info", []),
                    }
                ]

            sucessos = 0
            erros = []
            detalhes_sucesso = []

            for alvo in alvos:
                mid_atual = int(alvo.get("model_id") or 0)

                # Buscar promoção para este alvo específico
                promocao = self._get_active_promotion(
                    item_id, mid_atual if mid_atual > 0 else None, creds
                )

                if promocao:
                    promo_id = promocao.get("promotion_id") or promocao.get(
                        "discount_id"
                    )
                    resp, code = self._update_promotion_price(
                        promo_id,
                        item_id,
                        preco_novo,
                        mid_atual if mid_atual > 0 else None,
                        creds,
                        has_model=has_model,
                    )
                elif force_promotion:
                    # Tentar encontrar uma promoção ativa para vincular
                    ongoing_promo_id = self._find_any_ongoing_discount(creds)
                    if ongoing_promo_id:
                        # Criar payload para adicionar o item
                        item_to_add = {
                            "item_id": int(item_id),
                        }
                        if has_model and mid_atual > 0:
                            item_to_add["model_list"] = [
                                {
                                    "model_id": int(mid_atual),
                                    "model_promotion_price": float(preco_novo),
                                }
                            ]
                        else:
                            item_to_add["item_promotion_price"] = float(preco_novo)

                        resp, code = self.add_discount_item(
                            creds,
                            ongoing_promo_id,
                            [item_to_add],
                            log_msg="Anuncio colocado em promoção",
                            origem=origem,
                        )

                        # Se deu certo, precisamos marcar que é uma promoção para o logger
                        if code == 200 and not resp.get("error"):
                            promocao = {
                                "promotion_id": ongoing_promo_id,
                                "promotion_type": "Discount Promotions",
                            }
                    else:
                        return {
                            "status": "erro",
                            "mensagem": "Nenhuma promoção ativa (Ongoing) encontrada na loja para vincular o item.",
                        }
                else:
                    # --- NOVO: Validação de Segurança (Preço Base) ---
                    dias_espera = self._get_wait_time_config()
                    is_locked, _, lock_msg = self.validate_price_lock(
                        item_id, mid_atual
                    )
                    if is_locked:
                        self._criar_notificacao(
                            tipo="bloqueio",
                            titulo=f"Bloqueio de {dias_espera} Dias",
                            mensagem=f"{item_name} está Bloqueado Temporariamente, durante {dias_espera} Dias.",
                            item_id=str(item_id),
                            model_id=str(mid_atual),
                        )
                        return {"status": "erro", "mensagem": lock_msg}, 403

                    resp, code = self._update_base_price(
                        item_id,
                        preco_novo,
                        mid_atual if mid_atual > 0 else None,
                        creds,
                        has_model=has_model,
                    )

                self._salvar_log(
                    log_path, "AUTO", item_id, mid_atual, preco_novo, resp, code
                )

                # Na API v2, a Shopee pode retornar 200 com um campo "error" no JSON
                if code == 200 and not resp.get("error"):
                    sucessos += 1
                    # Registrar no banco local individualmente para manter histórico preciso
                    p_atual = 0.0
                    try:
                        p_atual = alvo["price_info"][0]["current_price"]
                    except:
                        pass

                    # Definir mensagem de log personalizada se for promoção
                    log_msg = custom_msg
                    if not log_msg:
                        if force_promotion:
                            log_msg = "Anuncio colocado em promoção"
                        elif promocao:
                            log_msg = "Anuncio em Promoção"
                        else:
                            log_msg = "Atualizado"

                    self._log_and_save_update(
                        item_id,
                        mid_atual,
                        item_name,
                        p_atual,
                        preco_novo,
                        "sucesso",
                        log_msg,
                        sku=(alvo.get("model_sku") or item_info.get("item_sku")),
                        promo_info=promocao,
                        origem=origem,
                    )

                    detalhes_sucesso.append(
                        {
                            "model_id": mid_atual,
                            "nome": alvo.get("model_name") or item_name,
                            "preco_anterior": p_atual,
                            "tipo": "promocional" if promocao else "base",
                        }
                    )
                else:
                    erro_msg = self._extrair_erro(resp)
                    erros.append({"model_id": mid_atual, "erro": erro_msg})

            if sucessos == 0 and alvos:
                return {
                    "status": "erro",
                    "mensagem": f"Falha ao atualizar na Shopee: {erros[0]['erro'] if erros else 'Erro desconhecido'}",
                    "detalhes": erros,
                }

            tipo_final = (
                "múltiplos"
                if len(alvos) > 1
                else ("promocional" if promocao else "base")
            )
            mensagem = f"Atualizado com sucesso {sucessos} de {len(alvos)} alvos."

            return {
                "status": "sucesso",
                "mensagem": mensagem,
                "detalhes": {
                    "item_id": item_id,
                    "sucessos": sucessos,
                    "total": len(alvos),
                    "itens_atualizados": detalhes_sucesso,
                    "erros": erros,
                },
            }

        except Exception as e:
            import traceback

            tb = traceback.format_exc()

            # Salvar traceback em arquivo
            try:
                error_log = os.path.join(LOG_DIR, "shopee_error.log")
                with open(error_log, "a", encoding="utf-8") as f:
                    f.write(f"\n--- {datetime.now()} ---\n{tb}\n")
            except:
                pass

            return {"status": "erro", "mensagem": f"Erro interno: {str(e)}"}

    def _extrair_erro(self, resp):
        """Extrai mensagem de erro legível de uma resposta Shopee v2."""
        if isinstance(resp, dict):
            # Prioridade para campos de erro da API v2
            if resp.get("error"):
                return f"{resp.get('error')}: {resp.get('message') or resp.get('msg') or 'Erro desconhecido'}"

            det = resp.get("detalhes", {})
            if isinstance(det, dict):
                return det.get("message") or det.get("msg") or json.dumps(det)

            return resp.get("message") or resp.get("msg") or json.dumps(resp)
        return str(resp)

    def _salvar_log(self, log_path, tipo, item_id, model_id, preco, resp, code):
        """Salva log de cada operação em arquivo."""
        try:
            with open(log_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "tipo": tipo,
                        "item_id": item_id,
                        "model_id": model_id,
                        "preco": preco,
                        "response": resp,
                        "status_code": code,
                        "time": str(datetime.now()),
                    },
                    f,
                    indent=4,
                    ensure_ascii=False,
                )
        except:
            pass

    def alterar_precos_lote(
        self,
        item_id,
        lista_precos,
        user_id=None,
        custom_msg=None,
        force_promotion=False,
        origem=None,
    ):
        """Versão lote - para importação de planilha ou Modal com variações."""
        creds, erro = self.tokens.ensure_valid_token(1)
        if erro:
            return {"status": "erro", "mensagem": f"Erro de autenticação: {erro}"}

        from model.shopeeModel import Produtos

        resultados = []
        for p_req in lista_precos:
            m_id = int(p_req.get("model_id") or 0)
            p_novo = float(p_req["preco"])

            # Buscar contexto para o histórico
            p_antigo = 0.0
            p_nome = "Produto"
            try:
                prod_local = Produtos.query.filter_by(
                    shopee_item_id=str(item_id), shopee_model_id=str(m_id)
                ).first()
                if prod_local:
                    p_antigo = (
                        prod_local.preco_promocional
                        if (
                            prod_local.preco_promocional
                            and prod_local.preco_promocional > 0
                        )
                        else prod_local.preco_base
                    )
                    p_nome = prod_local.nome_variacao or (
                        prod_local.anuncio.nome if prod_local.anuncio else "Produto"
                    )
            except:
                pass

            # Atualizar na Shopee
            res = self._atualizar_na_shopee(
                int(item_id),
                m_id,
                p_novo,
                creds,
                custom_msg=custom_msg,
                force_promotion=force_promotion,
                origem=origem,
            )

            resultados.append({"sku": p_req.get("sku"), **res})

        erros = [r for r in resultados if r.get("status") == "erro"]
        if erros:
            return {
                "status": "erro",
                "mensagem": f"{len(erros)} erro(s) de {len(resultados)}",
                "detalhes": resultados,
            }
        return {"status": "sucesso", "detalhes": resultados}

    def atualizar_preco_base_lote(self, item_id, price_list, creds):
        """Metodo de baixo nível para chamar a API com múltiplos preços de uma vez."""
        path = "/api/v2/product/update_price"
        payload = {"item_id": int(item_id), "price_list": price_list}
        return self.request_shopee(path, creds, payload)

    def atualizar_promocao_lote(self, discount_id, item_list, creds):
        """Metodo de baixo nível para atualizar vários produtos em um desconto."""
        path = "/api/v2/discount/update_discount_item"
        payload = {"discount_id": int(discount_id), "item_list": item_list}
        return self.request_shopee(path, creds, payload)

    def _criar_notificacao(self, tipo, titulo, mensagem, item_id=None, model_id=None):
        """Cria uma notificação no banco e emite via WebSocket."""
        try:
            from model.shopeeModel import NotificacaoSistema, db
            from app import socketio

            nova = NotificacaoSistema(
                tipo=tipo,
                titulo=titulo,
                mensagem=mensagem,
                shopee_item_id=str(item_id) if item_id else None,
                shopee_model_id=str(model_id) if model_id else None,
            )
            db.session.add(nova)
            db.session.commit()

            # Emitir via WebSocket para o frontend
            socketio.emit("nova_notificacao", nova.to_dict())
            return True
        except Exception as e:
            print(f"?? Erro ao criar notificação: {e}")
            return False

    def _registrar_no_banco(
        self,
        item_id,
        model_id,
        nome,
        preco_ant,
        preco_nv,
        item_info,
        promo_info,
        user_id=None,
    ):
        """Grava no histórico e garante que Pai/Filho existam no banco sem duplicidade."""
        try:
            agora = self.fusoBrasilia()
            from model.shopeeModel import Anuncios, Produtos

            # 1. Garantir que o Anúncio (Pai) existe
            anuncio = Anuncios.query.filter_by(shopee_item_id=str(item_id)).first()
            if not anuncio:
                anuncio = Anuncios(
                    shopee_item_id=str(item_id),
                    nome=nome or (item_info.get("item_name") if item_info else "Item"),
                    sku_pai=item_info.get("item_sku") if item_info else None,
                )
                db.session.add(anuncio)
                db.session.flush()

            # 2. Histórico de Preços
            historico = HistoricoPreco(
                shopee_item_id=str(item_id),
                shopee_model_id=str(model_id or "0"),
                nome_produto=nome,
                preco_anterior=float(preco_ant),
                preco_atual=float(preco_nv),
                status="sucesso",
                mensagem="Atualização realizada",
                usuario_id=user_id,
                criado_em=agora,
                sku=item_info.get("item_sku") if item_info else None,
            )
            db.session.add(historico)

            # 3. Garantir que o Produto existe e atualizar
            mid_str = str(model_id or "0")
            is_promo = promo_info is not None and (
                promo_info.get("promotion_id") or promo_info.get("discount_id")
            )

            produto = Produtos.query.filter_by(
                shopee_item_id=str(item_id), shopee_model_id=mid_str
            ).first()

            if not produto:
                produto = Produtos(
                    anuncio_id=anuncio.id,
                    shopee_item_id=str(item_id),
                    shopee_model_id=mid_str,
                    preco_base=preco_nv if not is_promo else 0.0,
                )
                db.session.add(produto)

            if is_promo:
                produto.preco_promocional = preco_nv
                produto.promotion_id = str(
                    promo_info.get("promotion_id") or promo_info.get("discount_id")
                )
            else:
                produto.preco_base = preco_nv
                produto.promotion_id = None
                produto.preco_promocional = None

            # Sincronizar nome se estiver vazio
            if item_info and (not anuncio.nome or anuncio.nome.isdigit()):
                anuncio.nome = item_info.get("item_name") or anuncio.nome

            produto.updated_at = agora
            produto.preco_modificado_em = agora  # Atualiza a trava de 15 dias
            anuncio.updated_at = agora
            db.session.commit()
        except Exception as e:
            print(f"⚠️ Error in _registrar_no_banco: {e}")
            db.session.rollback()

    # --- LÓGICA DE BUSCA ROBUSTA (v3) ---
    def buscar_todos_ids_sku(self, sku_alvo, creds):
        """Busca todas as variações/anúncios que usam o SKU."""
        all_matches = []
        unique_pairs = set()

        sku_norm = str(sku_alvo).strip().upper()
        prefixo = self._extrair_prefixo_sku(sku_norm)

        # 1. IDs Candidatos via API
        ids_candidatos = set()

        # Busca por variações comuns
        for s in [sku_norm, f"{sku_norm}-C1", f"{sku_norm}-C1-1", prefixo]:
            ids = self._call_search_item_ids(creds, item_sku=s)
            if ids:
                ids_candidatos.update(ids)

        # Busca por palavra-chave se ainda não achou nada
        if not ids_candidatos:
            ids = self._call_search_item_ids(creds, item_name=prefixo)
            if ids:
                ids_candidatos.update(ids)

        # 2. Varredura Local
        for iid in ids_candidatos:
            info = self._get_item_base_info(iid, creds)
            if not info:
                continue

            name = info.get("item_name", "Sem Nome")
            sku_pai = (info.get("item_sku") or "").strip().upper()

            # Confere Pai
            if sku_pai == sku_norm:
                if (iid, 0) not in unique_pairs:
                    unique_pairs.add((iid, 0))
                    all_matches.append(
                        {"item_id": iid, "model_id": 0, "sku": sku_pai, "name": name}
                    )

            # Confere Modelos
            if info.get("has_model"):
                modelos = self._get_models(iid, creds)
                for m in modelos:
                    m_sku = (m.get("model_sku") or "").strip().upper()
                    if m_sku == sku_norm:
                        if (iid, m["model_id"]) not in unique_pairs:
                            unique_pairs.add((iid, m["model_id"]))
                            all_matches.append(
                                {
                                    "item_id": iid,
                                    "model_id": m["model_id"],
                                    "sku": m_sku,
                                    "name": f"{name} [{m.get('model_name')}]",
                                }
                            )

        return all_matches

    def _extrair_prefixo_sku(self, sku):
        match = re.split(r"-(?:C\d+|V\d+|[A-Z]\d+)", sku, flags=re.IGNORECASE)
        if match and len(match[0]) > 3:
            return match[0]
        return sku.split("-")[0]

    # --- MÉTODOS DE SUPORTE (API) ---
    def _call_search_item_ids(self, creds, item_sku=None, item_name=None):
        path = "/api/v2/product/search_item"
        timestamp = int(time.time())
        string_base = f"{creds['partner_id']}{path}{timestamp}{creds['access_token']}{creds['shop_id']}"
        sign = hmac.new(
            creds["partner_key"].encode(), string_base.encode(), hashlib.sha256
        ).hexdigest()

        params = {
            "partner_id": int(creds["partner_id"]),
            "shop_id": int(creds["shop_id"]),
            "timestamp": timestamp,
            "access_token": creds["access_token"],
            "sign": sign,
            "page_size": 50,
        }
        if item_sku:
            params["item_sku"] = item_sku
        if item_name:
            params["item_name"] = item_name

        try:
            resp = requests.get(f"{self.host_base}{path}", params=params).json()
            return resp.get("response", {}).get("item_id_list", [])
        except:
            return []

    def _get_item_base_info(self, item_id, creds):
        res = self._get_item_base_info_batch([item_id], creds)
        return res[0] if res else None

    def _get_item_base_info_batch(self, item_id_list, creds):
        """Busca informações de múltiplos itens de uma vez (max 50)."""
        path = "/api/v2/product/get_item_base_info"
        ids_str = ",".join([str(i) for i in item_id_list])
        params = {"item_id_list": ids_str}

        resp_json, code = self._shopee_request(path, creds, params=params)
        if code == 200:
            return resp_json.get("response", {}).get("item_list", [])
        return []

    def _get_models(self, item_id, creds):
        """Busca variações (models) de um item."""
        path = "/api/v2/product/get_model_list"
        params = {"item_id": int(item_id)}
        resp_json, code = self._shopee_request(path, creds, params=params)
        if code == 200:
            return resp_json.get("response", {}).get("model", [])
        return []

    def _get_active_promotion(self, item_id, model_id, creds):
        """
        Identifica se há uma promoção ativa para o item/modelo.
        Prioriza 'Discount Promotions', pois é o único tipo editável via API de Descontos.
        """
        res = self._get_active_promotion_batch([item_id], creds)
        if not res:
            return None

        promos = res[0].get("promotion", [])

        # Filtrar promoções válidas para este modelo/item
        matches = []
        for p in promos:
            if p.get("promotion_id") or p.get("discount_id"):
                # Ignorar promoções de atacado (Whole Sale) que não são gerenciáveis via API de Descontos
                if p.get("promotion_type") == "Whole Sale":
                    continue

                if model_id:
                    if str(p.get("model_id", 0)) == str(model_id):
                        matches.append(p)
                else:
                    matches.append(p)

        if not matches:
            return None

        # 1. Tentar encontrar "Discount Promotions" (Prioridade Máxima)
        for p in matches:
            if p.get("promotion_type") == "Discount Promotions":
                return p

        # 2. Se não houver, retorna a primeira encontrada (Fallback)
        return matches[0]

    def _get_active_promotion_batch(self, item_id_list, creds):
        """Busca promoções para um lote de itens."""
        path = "/api/v2/product/get_item_promotion"
        ids_str = ",".join([str(i) for i in item_id_list])
        params = {"item_id_list": ids_str}

        resp_json, code = self._shopee_request(path, creds, params=params)
        if code == 200:
            return resp_json.get("response", {}).get("success_list", [])
        return []

    def _update_promotion_price(
        self, discount_id, item_id, price, model_id, creds, has_model=True
    ):
        """Atualiza o preço de uma promoção existente."""
        path = "/api/v2/discount/update_discount_item"
        item_data = {"item_id": int(item_id)}
        if has_model and model_id and int(model_id) > 0:
            item_data["model_list"] = [
                {"model_id": int(model_id), "model_promotion_price": float(price)}
            ]
        else:
            item_data["item_promotion_price"] = float(price)

        payload = {"discount_id": int(discount_id), "item_list": [item_data]}
        return self._shopee_request(path, creds, method="POST", json_data=payload)

    def _update_base_price(self, item_id, price, model_id, creds, has_model=True):
        """Atualiza o preço base (sem promoção) de um item."""
        path = "/api/v2/product/update_price"
        price_item = {"original_price": float(price)}
        if has_model and model_id and int(model_id) > 0:
            price_item["model_id"] = int(model_id)

        payload = {"item_id": int(item_id), "price_list": [price_item]}
        return self._shopee_request(path, creds, method="POST", json_data=payload)

    def process_spreadsheet(self, df):
        """
        Lógica de negócio para processar o DataFrame da planilha e salvar no banco local.
        """
        from model.shopeeModel import Anuncios, Produtos, db

        stats = {"sucesso": 0, "erro": 0}

        # Identificação de colunas (Lógica robusta movida das rotas)
        cols = [str(c).strip().lower() for c in df.columns]
        sku_key = next((c for i, c in enumerate(df.columns) if "sku" in cols[i]), None)
        price_key = next(
            (
                c
                for i, c in enumerate(df.columns)
                if "preco" in cols[i] or "preço" in cols[i] or "price" in cols[i]
            ),
            None,
        )
        id_item_key = next(
            (
                c
                for i, c in enumerate(df.columns)
                if "product_id" in cols[i] or "itemid" in cols[i]
            ),
            None,
        )
        id_model_key = next(
            (
                c
                for i, c in enumerate(df.columns)
                if "variation_id" in cols[i] or "model_id" in cols[i]
            ),
            None,
        )

        if not sku_key or not price_key:
            return None, "Colunas SKU ou Preço não identificadas."

        for _, row in df.iterrows():
            try:
                iid = (
                    str(row.get(id_item_key, "")).strip().replace(".0", "")
                    if id_item_key
                    else ""
                )
                mid = (
                    str(row.get(id_model_key, "0")).strip().replace(".0", "")
                    if id_model_key
                    else "0"
                )
                preco_nv = float(row[price_key])
                sku_raw = str(row.get(sku_key, "")).strip()

                if not iid.isdigit():
                    continue

                anuncio = Anuncios.query.filter_by(shopee_item_id=iid).first()
                if not anuncio:
                    anuncio = Anuncios(
                        shopee_item_id=iid, nome=f"Item {iid}", sku_pai=""
                    )
                    db.session.add(anuncio)
                    db.session.flush()

                produto = Produtos.query.filter_by(
                    shopee_item_id=iid, shopee_model_id=mid
                ).first()
                if not produto:
                    produto = Produtos(
                        anuncio_id=anuncio.id,
                        shopee_item_id=iid,
                        shopee_model_id=mid,
                        sku=sku_raw,
                        preco_base=preco_nv,
                    )
                    db.session.add(produto)
                else:
                    if produto.preco_promocional and produto.preco_promocional > 0:
                        produto.preco_promocional = preco_nv
                    else:
                        produto.preco_base = preco_nv
                    produto.sku = sku_raw
                    produto.updated_at = self._get_brasilia_time()
                    produto.preco_modificado_em = (
                        produto.updated_at
                    )  # Atualiza a trava de 15 dias
                    if produto.anuncio:
                        produto.anuncio.updated_at = produto.updated_at

                stats["sucesso"] += 1
            except:
                stats["erro"] += 1

        db.session.commit()
        return stats, None

    def validar_faixa_segura(self, preco_desejado, preco_atual):
        # Removendo a trava de 30% a pedido do usuário para que o preço mude exatamente para o desejado.
        return float(preco_desejado)

    # --- Módulo de Promoções (V2 Discount) ---
    def _find_any_ongoing_discount(self, creds):
        """Busca o ID da primeira promoção ativa (ongoing) na loja."""
        path = "/api/v2/discount/get_discount_list"
        params = {
            "page_no": 1,
            "page_size": 10,
            "discount_status": "ongoing",
        }
        resp, code = self._shopee_request(path, creds, params=params)
        if code == 200 and not resp.get("error"):
            discounts = resp.get("response", {}).get("discount_list", [])
            if discounts:
                return discounts[0]["discount_id"]
        return None

    def get_shopee_discounts(
        self, creds, status="all", page=1, page_size=100, force_sync=False
    ):
        """Busca lista de promoções (campanhas). Se force_sync=False, busca apenas no Banco de Dados local."""
        from model.shopeeModel import Promocoes, db
        from datetime import datetime
        import pytz

        # 1. Se NÃO for sincronização forçada, busca direto do Banco Local (Fast Load)
        if not force_sync:
            try:
                query = Promocoes.query
                if status and status != "all":
                    query = query.filter_by(status=status)

                # Paginação simples no banco se necessário, mas aqui retornamos tudo por enquanto
                promos = query.order_by(Promocoes.start_time.desc()).all()

                return {
                    "discount_list": [
                        {
                            "discount_id": str(p.discount_id),
                            "discount_name": p.discount_name,
                            "start_time": (
                                int(p.start_time.timestamp()) if p.start_time else 0
                            ),
                            "end_time": (
                                int(p.end_time.timestamp()) if p.end_time else 0
                            ),
                            "discount_status": p.status or "unknown",
                        }
                        for p in promos
                    ],
                    "more": False,
                    "source": "database",
                }
            except Exception as e:
                print(f"Erro ao buscar promoções no banco: {str(e)}")
                # Se der erro no banco, tenta o fluxo da API como fallback automático

        # 2. Fluxo de Sincronização Direta com a Shopee (API)
        path = "/api/v2/discount/get_discount_list"

        # Shopee API v2 OBRIGA o parâmetro discount_status (não aceita "all")
        if status == "all":
            statuses_to_fetch = ["ongoing", "upcoming", "expired"]
        else:
            statuses_to_fetch = [status]

        all_discounts = []

        try:
            for st in statuses_to_fetch:
                params = {
                    "page_no": page,
                    "page_size": page_size,
                    "discount_status": st,
                }
                resp, code = self._shopee_request(path, creds, params=params)

                if code == 200 and not resp.get("error"):
                    res = resp.get("response", {})
                    items = res.get("discount_list", [])

                    # Normalizar cada item para incluir discount_status e ID como string
                    for item in items:
                        # Mapear 'status' da Shopee para 'discount_status'
                        st_api = (
                            item.get("status")
                            or item.get("discount_status")
                            or "unknown"
                        )
                        item["discount_status"] = st_api
                        item["discount_id"] = str(item["discount_id"])

                    all_discounts.extend(items)

            # Sincronização com o Banco Local
            for d in all_discounts:
                try:
                    did = int(d["discount_id"])
                    nome = d["discount_name"]

                    # Converter timestamp para datetime (Shopee usa UTC)
                    inicio = datetime.fromtimestamp(
                        d.get("start_time", 0), pytz.UTC
                    ).replace(tzinfo=None)
                    fim = datetime.fromtimestamp(
                        d.get("end_time", 0), pytz.UTC
                    ).replace(tzinfo=None)

                    d_status = d.get("discount_status") or "unknown"

                    promo = Promocoes.query.filter_by(discount_id=did).first()
                    if promo:
                        promo.discount_name = nome
                        promo.start_time = inicio
                        promo.end_time = fim
                        promo.status = d_status
                        promo.updated_at = datetime.utcnow()
                    else:
                        promo = Promocoes(
                            discount_id=did,
                            discount_name=nome,
                            start_time=inicio,
                            end_time=fim,
                            status=d_status,
                        )
                        db.session.add(promo)
                except Exception as e:
                    print(
                        f"Erro ao persistir campanha {d.get('discount_id')}: {str(e)}"
                    )

            if all_discounts:
                db.session.commit()

            return {"discount_list": all_discounts, "more": False, "source": "api"}

        except Exception as e:
            print(f"🔄 Fallback get_shopee_discounts: {str(e)}")
            try:
                query = Promocoes.query
                if status and status != "all":
                    query = query.filter_by(status=status)

                promos = query.order_by(Promocoes.start_time.desc()).all()

                return {
                    "discount_list": [
                        {
                            "discount_id": str(p.discount_id),
                            "discount_name": p.discount_name,
                            "start_time": (
                                int(p.start_time.timestamp()) if p.start_time else 0
                            ),
                            "end_time": (
                                int(p.end_time.timestamp()) if p.end_time else 0
                            ),
                            "discount_status": p.status or "unknown",
                        }
                        for p in promos
                    ],
                    "more": False,
                }
            except Exception as ef:
                print(f"Falha crítica no fallback: {str(ef)}")
                return {"discount_list": [], "more": False}

    def add_shopee_discount(self, creds, name, start_time, end_time):
        """Cria uma nova campanha de promoção e salva no Banco Local."""
        from model.shopeeModel import Promocoes, db
        from datetime import datetime
        import pytz

        path = "/api/v2/discount/add_discount"
        payload = {
            "discount_name": name,
            "start_time": int(start_time),
            "end_time": int(end_time),
        }
        resp, code = self._shopee_request(path, creds, method="POST", json_data=payload)

        if code == 200:
            did = resp.get("response", {}).get("discount_id")
            if did:
                promo = Promocoes(
                    discount_id=did,
                    discount_name=name,
                    start_time=datetime.fromtimestamp(
                        int(start_time), pytz.UTC
                    ).replace(tzinfo=None),
                    end_time=datetime.fromtimestamp(int(end_time), pytz.UTC).replace(
                        tzinfo=None
                    ),
                    status="upcoming",  # Por padrão a Shopee cria com delay
                )
                db.session.add(promo)
                db.session.commit()
                # Converter ID no response para string
                resp["response"]["discount_id"] = str(did)

        return resp, code

    def get_shopee_discount_detail(self, discount_id):
        """Busca os detalhes de uma campanha específica no Banco Local."""
        from model.shopeeModel import Promocoes

        promo = Promocoes.query.filter_by(discount_id=int(discount_id)).first()
        if promo:
            return {
                "discount_id": str(promo.discount_id),
                "discount_name": promo.discount_name,
                "start_time": (
                    int(promo.start_time.timestamp()) if promo.start_time else 0
                ),
                "end_time": int(promo.end_time.timestamp()) if promo.end_time else 0,
                "discount_status": promo.status,
            }
        return None

    def delete_shopee_discount(self, creds, discount_id):
        """Exclui uma campanha agendada (Upcoming)."""
        path = "/api/v2/discount/delete_discount"
        payload = {"discount_id": int(discount_id)}
        return self._shopee_request(path, creds, method="POST", json_data=payload)

    def end_shopee_discount(self, creds, discount_id):
        """Encerra uma campanha ativa (Ongoing)."""
        path = "/api/v2/discount/end_discount"
        payload = {"discount_id": int(discount_id)}
        return self._shopee_request(path, creds, method="POST", json_data=payload)

    def get_discount_item_list(
        self, creds, discount_id, page=1, page_size=20, search=None
    ):
        """Lista os itens vinculados a uma promoção, sincronizando com a Shopee para garantir consistência."""
        from model.shopeeModel import Produtos, Anuncios

        # 1. Sincronização Ativa com a Shopee (Sempre executada na primeira página para garantir dados novos)
        if page == 1:
            try:
                path = "/api/v2/discount/get_discount_item_list"
                params = {
                    "discount_id": int(discount_id),
                    "page_no": 1,
                    "page_size": 100,  # Busca um lote maior para popular o banco inicialmente
                }
                resp, code = self._shopee_request(path, creds, params=params)

                if code == 200 and "response" in resp:
                    res = resp.get("response", {})
                    raw_items = res.get("item_list", [])

                    # Marcar IIDs e MIDs que estão na Shopee para limpar os que saíram
                    current_item_models = set()

                    for item in raw_items:
                        iid = str(item.get("item_id"))
                        models = item.get("model_list", [])

                        # Processar cada variação ou o item base se não houver modelos
                        model_data_list = models if models else [item]
                        for m in model_data_list:
                            mid = str(m.get("model_id", "0"))

                            # Conversões robustas para evitar crash com nulls da API
                            try:
                                orig = float(m.get("original_price") or 0.0)
                                promo = float(
                                    m.get("promotion_price")
                                    or item.get("item_promotion_price")
                                    or 0.0
                                )
                            except (TypeError, ValueError):
                                orig = 0.0
                                promo = 0.0

                            current_item_models.add((iid, mid))

                            # Atualizar ou criar registro local se necessário (só se já tivermos o anúncio indexado)
                            p = Produtos.query.filter_by(
                                shopee_item_id=iid, shopee_model_id=mid
                            ).first()
                            if p:
                                p.promotion_id = str(discount_id)
                                p.preco_promocional = promo
                                if orig > 0:
                                    p.preco_base = orig

                    # Limpeza: itens que estavam nesta campanha localmente mas NÃO vieram na api da Shopee
                    others = Produtos.query.filter(
                        Produtos.promotion_id == str(discount_id)
                    ).all()
                    for op in others:
                        if (
                            op.shopee_item_id,
                            op.shopee_model_id,
                        ) not in current_item_models:
                            op.promotion_id = None
                            op.preco_promocional = None

                    db.session.commit()
            except Exception as e:
                db.session.rollback()
                import traceback

                print(f"⚠️ Erro na sincronização passiva de campanha {discount_id}: {e}")
                traceback.print_exc()

        # 2. Busca no Banco Local (Após sincronização ou para páginas subsequentes)
        flat_items = []
        from sqlalchemy import or_

        query = (
            db.session.query(Produtos, Anuncios.nome)
            .join(Anuncios, Produtos.shopee_item_id == Anuncios.shopee_item_id)
            .filter(Produtos.promotion_id == str(discount_id))
        )

        if search:
            search_str = f"%{search}%"
            query = query.filter(
                or_(
                    Anuncios.nome.ilike(search_str),
                    Anuncios.sku_pai.ilike(search_str),
                    Produtos.sku.ilike(search_str),
                    Produtos.shopee_item_id.ilike(search_str),
                    Produtos.shopee_model_id.ilike(search_str),
                )
            )

        query_db = query.all()

        if query_db:
            total_items = len(query_db)
            total_pages = math.ceil(total_items / page_size)

            # Paginação Local
            start = (page - 1) * page_size
            end = start + page_size
            page_items = query_db[start:end]
            has_more = total_items > end

            for p, item_nome in page_items:
                flat_items.append(
                    {
                        "item_id": str(p.shopee_item_id),
                        "item_name": item_nome,
                        "model_id": str(p.shopee_model_id or "0"),
                        "model_name": p.nome_variacao or "Padrão",
                        "original_price": p.preco_base,
                        "promotion_price": p.preco_promocional or 0,
                        "stock": 0,
                    }
                )

            return {
                "item_list": flat_items,
                "total": total_items,
                "pages": total_pages,
                "more": has_more,
            }

        return {"item_list": [], "total": 0, "pages": 0, "more": False}

    def add_discount_item(
        self, creds, discount_id, items, log_msg="Anuncio em Promoção", origem=None
    ):
        """
        Adiciona itens a uma promoção existente e atualiza o Banco Local.
        """
        # --- NOVO: Validação de Segurança (Preço Base Inflado) ---
        for itm in items:
            iid = str(itm.get("item_id"))
            models = itm.get("model_list", [])
            if models:
                for m in models:
                    mid = str(m.get("model_id"))
                    is_locked, _, msg = self.validate_price_lock(iid, mid)
                    if is_locked:
                        # Retornar no formato que a rota espera (que por sua vez repassa o status_code)
                        return {
                            "status": "erro",
                            "error": "error_param",
                            "message": msg,
                            "mensagem": msg,
                        }, 403
            else:
                is_locked, _, msg = self.validate_price_lock(iid, 0)
                if is_locked:
                    return {
                        "status": "erro",
                        "error": "error_param",
                        "message": msg,
                        "mensagem": msg,
                    }, 403
        # ---------------------------------------------------------

        path = "/api/v2/discount/add_discount_item"
        payload = {"discount_id": int(discount_id), "item_list": items}
        resp, code = self._shopee_request(path, creds, method="POST", json_data=payload)

        if code == 200:
            # Sincronizar Localmente
            for itm in items:
                iid = str(itm.get("item_id"))
                models = itm.get("model_list", [])
                if models:
                    for m in models:
                        mid = str(m.get("model_id"))
                        price = float(m.get("model_promotion_price") or 0)
                        p = Produtos.query.filter_by(
                            shopee_item_id=iid, shopee_model_id=mid
                        ).first()
                        if p:
                            p.promotion_id = str(discount_id)
                            p.preco_promocional = price

                            # Logar no Histórico
                            from flask import g

                            u_id = (
                                getattr(g, "current_user", None).id
                                if hasattr(g, "current_user") and g.current_user
                                else None
                            )
                            self._log_and_save_update(
                                iid,
                                mid,
                                p.nome_variacao
                                or (p.anuncio.nome if p.anuncio else "Produto"),
                                p.preco_base,  # Preço antigo (base)
                                price,  # Preço novo (promo)
                                "sucesso",
                                log_msg,
                                sku=p.sku,
                                promo_info={"promotion_id": discount_id},
                                usuario_id=u_id,
                                origem=origem,
                            )
                else:
                    price = float(itm.get("item_promotion_price", 0))
                    p = Produtos.query.filter_by(
                        shopee_item_id=iid, shopee_model_id="0"
                    ).first()
                    if p:
                        p.promotion_id = str(discount_id)
                        p.preco_promocional = price

                        # Logar no Histórico
                        from flask import g

                        u_id = (
                            getattr(g, "current_user", None).id
                            if hasattr(g, "current_user") and g.current_user
                            else None
                        )
                        self._log_and_save_update(
                            iid,
                            "0",  # Model ID para produto simples é sempre "0"
                            p.nome_variacao
                            or (p.anuncio.nome if p.anuncio else "Produto"),
                            p.preco_base,  # Preço antigo (base)
                            price,  # Preço novo (promo)
                            "sucesso",
                            log_msg,
                            sku=p.sku,
                            promo_info={"promotion_id": discount_id},
                            usuario_id=u_id,
                            origem=origem,
                        )
            db.session.commit()

        return resp, code

    def delete_discount_item(self, creds, discount_id, item_id, model_id=0):
        """Remove um item de uma promoção e limpa o Banco Local."""
        path = "/api/v2/discount/delete_discount_item"
        payload = {"discount_id": int(discount_id), "item_id": int(item_id)}
        if model_id and int(model_id) > 0:
            payload["model_id"] = int(model_id)

        resp, code = self._shopee_request(path, creds, method="POST", json_data=payload)

        if code == 200:
            # Limpar Localmente
            mid = str(model_id) if model_id and int(model_id) > 0 else "0"
            p = Produtos.query.filter_by(
                shopee_item_id=str(item_id), shopee_model_id=mid
            ).first()
            if p:
                p.promotion_id = None
                p.preco_promocional = None
            db.session.commit()

        return resp, code
